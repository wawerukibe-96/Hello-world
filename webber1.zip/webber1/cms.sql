-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 07, 2020 at 04:09 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(11) NOT NULL,
  `cat_title` varchar(255) NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'Tech'),
(2, 'Product'),
(3, 'GOODS');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comment_id` int(3) NOT NULL,
  `comment_post_id` int(3) NOT NULL,
  `comment_author` varchar(255) NOT NULL DEFAULT 'N',
  `comment_email` varchar(255) NOT NULL DEFAULT 'NOT NULL',
  `comment_content` varchar(255) NOT NULL DEFAULT 'NOT NULL',
  `comment_status` varchar(255) NOT NULL DEFAULT 'NOT NULL',
  `comment_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `comment_post_id`, `comment_author`, `comment_email`, `comment_content`, `comment_status`, `comment_date`) VALUES
(1, 1, 'kibe', 'shon@gmail.com', 'that\'s right, we all agree with this statement', 'Approved', '2020-10-09 16:48:30'),
(2, 8, 'dan', 'jusper@wendo.com', 'bvgdfszzfstfh ;ljufgydfhb', 'Approved', '2020-10-11 16:41:58'),
(3, 21, 'fngn', 'shon@gmail.com', 'egfyt45tfgjsf', 'Unapproved', '2020-11-02 14:34:14');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `post_id` int(3) NOT NULL,
  `post_category_id` int(3) NOT NULL,
  `post_title` varchar(255) NOT NULL DEFAULT 'NOT NULL',
  `post_author` varchar(255) NOT NULL DEFAULT 'NOT NULL',
  `post_user` varchar(255) NOT NULL,
  `post_date` datetime NOT NULL,
  `post_image` text NOT NULL DEFAULT 'NOT NULL',
  `post_content` varchar(255) NOT NULL DEFAULT 'NOT NULL',
  `post_payment` varchar(255) NOT NULL DEFAULT 'NOT NULL',
  `post_tags` varchar(255) NOT NULL DEFAULT 'NOT NULL',
  `post_comment_count` varchar(255) NOT NULL DEFAULT 'NOT NULL',
  `post_status` varchar(255) NOT NULL DEFAULT 'NOT NULL DEFAULT Únpaid',
  `post_views_count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `post_category_id`, `post_title`, `post_author`, `post_user`, `post_date`, `post_image`, `post_content`, `post_payment`, `post_tags`, `post_comment_count`, `post_status`, `post_views_count`) VALUES
(9, 1, ' L.A.N', 'NOT NULL', 'shon', '2020-11-02 11:25:18', 'net1.jpg', '<p style=\"text-align: center;\"><strong><span style=\"text-decoration: underline; color: #2dc26b;\">L.A.N CABLES.</span></strong></p>\r\n<p style=\"text-align: left;\"><span style=\"font-size: 10pt;\">This cables are good strong and long lasting .on top of that th', 'NOT NULL', 'Fast and  pocket friendly', 'NOT NULL', 'Unpaid', 6),
(10, 1, 'Repairs', 'NOT NULL', 'shon', '2020-11-02 11:59:39', 'board1.jpg', '<h1 style=\"text-align: center;\"><span style=\"text-decoration: underline; color: #843fa1;\">P.C Repairs</span>.</h1>\r\n<p>get your pcs repaired in an easier and faster way.</p>', 'NOT NULL', 'P.Cs repairs', 'NOT NULL', 'Unpaid', 2),
(11, 3, 'vfv', 'NOT NULL', 'shon', '2020-11-02 14:44:17', 'c1.jpg', '<p>efefew</p>', 'NOT NULL', 'dffeef', 'NOT NULL', 'Paid', 4),
(13, 1, 'Repairs', 'NOT NULL', '', '2020-11-02 13:55:17', 'board1.jpg', '<h1 style=\"text-align: center;\"><span style=\"text-decoration: underline; color: #843fa1;\">P.C Repairs</span>.</h1>\r\n<p>get your pcs repaired in an easier and faster way.</p>', 'NOT NULL', 'P.Cs repairs', 'NOT NULL', 'Unpaid', 1),
(14, 1, ' L.A.N', 'NOT NULL', '', '2020-11-02 13:55:17', 'net1.jpg', '<p style=\"text-align: center;\"><strong><span style=\"text-decoration: underline; color: #2dc26b;\">L.A.N CABLES.</span></strong></p>\r\n<p style=\"text-align: left;\"><span style=\"font-size: 10pt;\">This cables are good strong and long lasting .on top of that th', 'NOT NULL', 'Fast and  pocket friendly', 'NOT NULL', 'Unpaid', 1),
(15, 1, ' L.A.N', 'NOT NULL', 'ngimwa', '2020-11-02 14:46:32', 'net1.jpg', '<p><strong>L.A.N CABLES.</strong></p>\r\n<p>\\r\\n</p>\r\n<p>\\\\r\\\\n</p>\r\n<p>\\r\\n</p>\r\n<p>\\\\\\\\r\\\\\\\\n</p>\r\n<p>\\r\\n</p>\r\n<p>\\\\r\\\\n</p>\r\n<p>\\r\\n</p>\r\n<p>This cables are good strong and long lasting .on top of that th</p>', 'NOT NULL', 'Fast and  pocket friendly', 'NOT NULL', 'Paid', 2),
(16, 1, 'Repairs', 'NOT NULL', '', '2020-11-02 13:55:44', 'board1.jpg', '<h1 style=\"text-align: center;\"><span style=\"text-decoration: underline; color: #843fa1;\">P.C Repairs</span>.</h1>\r\n<p>get your pcs repaired in an easier and faster way.</p>', 'NOT NULL', 'P.Cs repairs', 'NOT NULL', 'Unpaid', 0),
(17, 2, 'vfv', 'NOT NULL', 'shon', '2020-11-02 14:49:44', 'bak4.jpg', '<p>efefew</p>', 'NOT NULL', 'dffeef', 'NOT NULL', 'Paid', 1),
(18, 1, 'Repairs', 'NOT NULL', 'shon', '2020-11-02 14:10:14', 'board1.jpg', '<h1 style=\"text-align: center;\"><span style=\"text-decoration: underline; color: #843fa1;\">P.C Repairs</span>.</h1>\r\n<p>get your pcs repaired in an easier and faster way.</p>', 'NOT NULL', 'P.Cs repairs', 'NOT NULL', 'Paid', 1),
(19, 1, ' L.A.N', 'NOT NULL', '', '2020-11-02 13:55:44', 'net1.jpg', '<p style=\"text-align: center;\"><strong><span style=\"text-decoration: underline; color: #2dc26b;\">L.A.N CABLES.</span></strong></p>\r\n<p style=\"text-align: left;\"><span style=\"font-size: 10pt;\">This cables are good strong and long lasting .on top of that th', 'NOT NULL', 'Fast and  pocket friendly', 'NOT NULL', 'Unpaid', 0),
(20, 1, ' L.A.N', 'NOT NULL', '', '2020-11-02 13:56:14', 'net1.jpg', '<p style=\"text-align: center;\"><strong><span style=\"text-decoration: underline; color: #2dc26b;\">L.A.N CABLES.</span></strong></p>\r\n<p style=\"text-align: left;\"><span style=\"font-size: 10pt;\">This cables are good strong and long lasting .on top of that th', 'NOT NULL', 'Fast and  pocket friendly', 'NOT NULL', 'Paid', 0),
(21, 1, 'Repairs', 'NOT NULL', '', '2020-11-02 13:56:14', 'board1.jpg', '<h1 style=\"text-align: center;\"><span style=\"text-decoration: underline; color: #843fa1;\">P.C Repairs</span>.</h1>\r\n<p>get your pcs repaired in an easier and faster way.</p>', 'NOT NULL', 'P.Cs repairs', 'NOT NULL', 'Paid', 4),
(22, 3, 'price', 'NOT NULL', 'shon', '2020-11-04 18:09:13', 'main.jpg', '<p>DGGFA KJGGGGHDSHGSJKVGZ .X,KJSHDHGDFGRGH,GFWRER</p>', 'NOT NULL', 'Lacasa de papel.', 'NOT NULL', 'Paid', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(3) NOT NULL,
  `username` varchar(255) NOT NULL DEFAULT 'NOT NULL',
  `user_password` varchar(255) NOT NULL DEFAULT 'NOT NULL',
  `user_firstname` varchar(255) NOT NULL DEFAULT 'NOT NULL',
  `user_lastname` varchar(255) NOT NULL DEFAULT 'NOT NULL',
  `user_email` varchar(255) NOT NULL DEFAULT 'NOT NULL',
  `user_image` text NOT NULL DEFAULT 'NOT NULL',
  `user_role` varchar(255) NOT NULL DEFAULT 'NOT NULL'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `user_password`, `user_firstname`, `user_lastname`, `user_email`, `user_image`, `user_role`) VALUES
(1, 'shon', '$2y$12$vd8pjlnoOJYSwJlWGrfUvOSVxsGt9UQBu7kakpV4IzVohYZ2NEs86', 'shon', 'kibe', 'shon@gmail.com', 'NOT NULL', 'Admin'),
(2, 'ngimwa', '$2y$10$gpGt8VQcvgD.ImTsw1DWsO1eQaBz/jxKmx3MKP2pUEadFyPEf1i0O', 'mwangi', 'Mwai', 'mgichimu8@gmail.com', 'NOT NULL', 'Subscriber'),
(3, 'sly', '$2y$12$czFmFMA59LAvmH/RxmKYXOUjIVx8pXTsK7p6fZsPgJ8H9AJWsoZIu', 'sylvia', 'wangechi', 'silvia@sly.com', 'NOT NULL', 'Subscriber'),
(4, 'dan', '$2y$10$9Bx2DpECvcEthvgXTPMP3OMIra//YmvAux1gZ.5CE1GGKT7FRlGFa', 'dan', 'muriuki', 'dan@gmail.com', 'NOT NULL', 'Admin'),
(5, 'Jymoh', '$2y$12$12CvCaBg3GoAawNACz6ZdOyi80Oz4CWnqLlYmOzO91CbMXXHcQ3ce', 'James ', ' Ngángá', 'jymoh@gmail.com', 'NOT NULL', 'Subscriber'),
(6, 'sudi', '$2y$12$6mYt2b0DqfVZpMNkd9h/zuzSINC2CmLflxLShVBzIuh5AMLnBkzJ6', 'joel', 'peter', 'sudi@sudii', 'NOT NULL', 'Subscriber');

-- --------------------------------------------------------

--
-- Table structure for table `users_online`
--

CREATE TABLE `users_online` (
  `id` int(3) NOT NULL,
  `session` varchar(255) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users_online`
--

INSERT INTO `users_online` (`id`, `session`, `time`) VALUES
(1, '8evv4tk3rgesbdq3vd2aijco8r', 1602423846),
(2, 'fb2qabd1sqdsak5f8b8gbpc7kq', 1603535354),
(3, 'uba8nfoacqqklrhggjbj7srnsb', 1604301248),
(4, '0er4cqadfalnaflg39kh6sv0b1', 1604314757),
(5, '5hdcj73tpjg0dvp6s13pb3t7oh', 1604317787),
(6, '1s7f3imrucmi5om6i2e1nothvq', 1604386047),
(7, '9pka42m4jmrh775l60gguc5vgm', 1604761752);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `users_online`
--
ALTER TABLE `users_online`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users_online`
--
ALTER TABLE `users_online`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
