<?php ob_start();
 $connection = mysqli_connect('localhost','root','', 'adverts');

 if (!$connection) {
  	
  	die("Database connection failed");
  } 

?>